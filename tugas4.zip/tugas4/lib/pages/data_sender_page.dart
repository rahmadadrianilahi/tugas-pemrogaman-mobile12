import 'package:flutter/material.dart';
import 'data_receiver_page.dart';

class DataSenderPage extends StatefulWidget {
  const DataSenderPage({super.key});

  @override
  State<DataSenderPage> createState() => _DataSenderPageState();
}

class _DataSenderPageState extends State<DataSenderPage> {
  final TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kirim Data"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: messageController,
              decoration: const InputDecoration(
                labelText: "Tulis Pesan",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                String pesan = messageController.text;

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DataReceiverPage(message: pesan),
                  ),
                );
              },
              child: const Text("Kirim ke Halaman Lain"),
            )
          ],
        ),
      ),
    );
  }
}
