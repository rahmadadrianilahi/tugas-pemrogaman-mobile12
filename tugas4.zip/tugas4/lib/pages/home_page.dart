import 'package:flutter/material.dart';
import 'second_page.dart';
import 'data_sender_page.dart';
import 'bottom_nav_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
      ),
      body: Column(
        children: [
          // Header di atas
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  "Selamat Datang di Flutter Navigation!",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  "Pilih menu di bawah untuk mencoba fitur navigasi:",
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 40),

                // Logo Kampus di tengah
                Center(
                  child: Image.asset(
                    'assets/logo_uin.png',
                    width: 120,
                    height: 120,
                  ),
                ),
              ],
            ),
          ),

          // Tombol-tombol di tengah
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SecondPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text("Pergi ke Halaman Kedua"),
                    ),
                    const SizedBox(height: 14),

                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const DataSenderPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text("Kirim Data ke Halaman Lain"),
                    ),
                    const SizedBox(height: 14),

                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const BottomNavPage()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.lightBlue,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text("Halaman dengan BottomNavigationBar"),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Credit di bawah
          Padding(
            padding: const EdgeInsets.all(20),
            child: const Text(
              "Dibuat oleh: Nandicho Naufal Riza (701230092)",
              style: TextStyle(
                fontSize: 14,
                fontStyle: FontStyle.italic,
                color: Colors.grey,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}