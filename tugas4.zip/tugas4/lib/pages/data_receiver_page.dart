import 'package:flutter/material.dart';

class DataReceiverPage extends StatelessWidget {
  final String message;

  const DataReceiverPage({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Terima Data"),
      ),
      body: Center(
        child: Text(
          "Pesan diterima: $message",
          style: const TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
