import 'package:flutter/material.dart';

class BottomNavPage extends StatefulWidget {
  const BottomNavPage({super.key});

  @override
  State<BottomNavPage> createState() => _BottomNavPageState();
}

class _BottomNavPageState extends State<BottomNavPage> {
  int currentIndex = 0;

  // List untuk menyimpan riwayat aktivitas
  List<Map<String, dynamic>> activities = [];

  @override
  void initState() {
    super.initState();
    // Tambah aktivitas awal saat halaman dibuka
    _addActivity("Membuka Bottom Navigation");
  }

  // Fungsi untuk menambah aktivitas baru
  void _addActivity(String title) {
    setState(() {
      activities.insert(0, {
        'title': title,
        'time': DateTime.now(),
      });
    });
  }

  // Fungsi untuk menghitung waktu yang lalu
  String _getTimeAgo(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inSeconds < 60) {
      return 'Baru saja';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} menit lalu';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} jam lalu';
    } else if (difference.inDays == 1) {
      return 'Kemarin';
    } else {
      return '${difference.inDays} hari lalu';
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildHomePage(),
      _buildActivityPage(),
      _buildProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Bottom Navigation"),  // Diubah dari "Bottom Navigation Example"
      ),
      body: pages[currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (index) {
          setState(() {
            currentIndex = index;

            // Catat aktivitas berdasarkan tab yang dipilih
            if (index == 0) {
              _addActivity("Membuka Dashboard");
            } else if (index == 1) {
              _addActivity("Melihat Riwayat Aktivitas");
            } else if (index == 2) {
              _addActivity("Mengakses Halaman Profile");
            }
          });
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: "Home"),
          NavigationDestination(icon: Icon(Icons.list_alt), label: "Activity"),
          NavigationDestination(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }

  // -------------------------------
  // HOME PAGE
  // -------------------------------
  Widget _buildHomePage() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            "Selamat Datang di Dashboard!",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              _addActivity("Menekan Tombol di Dashboard");
            },
            child: const Text("Klik untuk Test Aktivitas"),
          ),
        ],
      ),
    );
  }

  // -------------------------------
  // ACTIVITY PAGE
  // -------------------------------
  Widget _buildActivityPage() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          "Riwayat Aktivitas",
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),

        // Tampilkan pesan jika belum ada aktivitas
        if (activities.isEmpty)
          const Center(
            child: Text(
              "Belum ada aktivitas",
              style: TextStyle(color: Colors.grey),
            ),
          )
        else
        // Tampilkan semua aktivitas dari list
          ...activities.map((activity) {
            return _buildActivityTile(
              activity['title'],
              _getTimeAgo(activity['time']),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildActivityTile(String title, String time) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.check_circle_outline),
        title: Text(title),
        subtitle: Text(time),
      ),
    );
  }

  // -------------------------------
  // PROFILE PAGE
  // -------------------------------
  Widget _buildProfilePage() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: ListView(
        children: [
          const CircleAvatar(
            radius: 50,
            child: Icon(Icons.person, size: 50),
          ),
          const SizedBox(height: 20),

          const Text(
            "Data Profil Mahasiswa",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),

          _buildInfoTile("Nama", "Nandicho Naufal Riza"),
          _buildInfoTile("NIM", "701230092"),
          _buildInfoTile("Kelas", "5D"),
          _buildInfoTile("Prodi", "Sistem Informasi"),
          _buildInfoTile("Fakultas", "Sains dan Teknologi"),
          _buildInfoTile(
              "Universitas", "Universitas Islam Negeri Sultan Thaha Saifuddin Jambi"),
          _buildInfoTile("Mata Kuliah", "Pemrograman Mobile"),
          _buildInfoTile("Dosen Pengampu", "Ahmad Nasukha, S.Hum., M.S.I"),
        ],
      ),
    );
  }

  Widget _buildInfoTile(String title, String value) {
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(value),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          _addActivity("Melihat Informasi $title");
        },
      ),
    );
  }
}