import 'package:flutter/material.dart';
import 'pages/home_page.dart';

void main() {
  runApp(const FlutterNavigation());
}

class FlutterNavigation extends StatelessWidget {
  const FlutterNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Flutter Navigation",
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}
