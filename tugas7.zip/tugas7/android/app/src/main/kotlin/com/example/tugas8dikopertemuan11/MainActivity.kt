package com.example.tugas8dikopertemuan11

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
