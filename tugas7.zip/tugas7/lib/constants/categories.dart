import 'package:flutter/material.dart';

class CategoryData {
  static const List<String> categories = [
    'Semua',
    'Kuliah',
    'Organisasi',
    'Pribadi',
    'Lain-lain',
  ];

  static IconData getCategoryIcon(String category) {
    switch (category) {
      case 'Kuliah':
        return Icons.school;
      case 'Organisasi':
        return Icons.groups;
      case 'Pribadi':
        return Icons.person;
      case 'Lain-lain':
        return Icons.more_horiz;
      default:
        return Icons.note;
    }
  }

  static Color getCategoryColor(String category) {
    switch (category) {
      case 'Kuliah':
        return Colors.blue;
      case 'Organisasi':
        return Colors.green;
      case 'Pribadi':
        return Colors.orange;
      case 'Lain-lain':
        return Colors.grey;
      default:
        return Colors.purple;
    }
  }
}