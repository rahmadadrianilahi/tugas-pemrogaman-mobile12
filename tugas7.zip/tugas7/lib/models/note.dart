class Note {
  String id;
  String title;
  String description;
  String category;
  DateTime dateCreated;

  Note({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.dateCreated,
  });

  // Convert to JSON for SharedPreferences
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'category': category,
      'dateCreated': dateCreated.toIso8601String(),
    };
  }

  // Create from JSON
  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      category: json['category'],
      dateCreated: DateTime.parse(json['dateCreated']),
    );
  }
}