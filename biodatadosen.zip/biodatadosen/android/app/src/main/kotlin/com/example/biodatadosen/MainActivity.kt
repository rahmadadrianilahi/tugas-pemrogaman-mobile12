package com.example.biodatadosen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
