# Generated code do not commit.
file(TO_CMAKE_PATH "D:\\KULIAH\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Microsoft\\StudioProjects\\biodatadosen" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=D:\\KULIAH\\flutter"
  "PROJECT_DIR=C:\\Users\\Microsoft\\StudioProjects\\biodatadosen"
  "FLUTTER_ROOT=D:\\KULIAH\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Microsoft\\StudioProjects\\biodatadosen\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Microsoft\\StudioProjects\\biodatadosen"
  "FLUTTER_TARGET=C:\\Users\\Microsoft\\StudioProjects\\biodatadosen\\lib\\main.dart"
  "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9WRVJTSU9OPTMuMzUuNQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YWM0ZTc5OWQyMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZDNkNDVkY2YyNQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My45LjI="
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\Microsoft\\StudioProjects\\biodatadosen\\.dart_tool\\package_config.json"
)
