import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daftar Dosen UIN STS Jambi',
      theme: ThemeData(
        primarySwatch: Colors.red,
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: const DaftarDosenPage(),
    );
  }
}

class DaftarDosenPage extends StatelessWidget {
  const DaftarDosenPage({super.key});

  // Daftar data dosen
  final List<Map<String, dynamic>> dosenList = const [
    {
      'nama': 'Diko S.Kom',
      'nip': '1234567890',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Pemrograman Web & Mobile',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Indonesia',
      'email': 'diko@gmail.com',
      'noHp': '081234567890',
      'alamat': 'Jl. Pattimura No.45, Jambi Selatan',
      'tanggalLahir': '12 Maret 1987',
      'jenisKelamin': 'Laki-laki',
      'umur': '38 Tahun',
      'riwayat': 'Mengajar selama 10 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Andi M.Kom',
      'nip': '9876543210',
      'jabatan': 'Dosen Luar Biasa',
      'bidang': 'Jaringan Komputer',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Gadjah Mada',
      'email': 'andi@gmail.com',
      'noHp': '082198765432',
      'alamat': 'Jl. Raden Mattaher No. 23, Kota Jambi',
      'tanggalLahir': '5 Juni 1985',
      'jenisKelamin': 'Laki-laki',
      'umur': '40 Tahun',
      'riwayat': 'Mengajar selama 8 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Siti Rahmawati M.Pd',
      'nip': '3216549870',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Pendidikan & Pengajaran',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Negeri Jakarta',
      'email': 'rahmawati@gmail.com',
      'noHp': '081234567321',
      'alamat': 'Jl. Sultan Thaha No. 88, Jambi Timur',
      'tanggalLahir': '20 November 1989',
      'jenisKelamin': 'Perempuan',
      'umur': '35 Tahun',
      'riwayat': 'Mengajar selama 9 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Rizki Pratama M.T',
      'nip': '6549873210',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Teknologi Informasi',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Institut Teknologi Bandung',
      'email': 'rizki@gmail.com',
      'noHp': '081233445566',
      'alamat': 'Jl. Kapten Pattimura No. 12, Jambi',
      'tanggalLahir': '9 April 1986',
      'jenisKelamin': 'Laki-laki',
      'umur': '39 Tahun',
      'riwayat': 'Mengajar selama 11 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Nadia Fadhilah S.Pd',
      'nip': '9873214560',
      'jabatan': 'Dosen Luar Biasa',
      'bidang': 'Pendidikan Bahasa Inggris',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Negeri Padang',
      'email': 'nadia@gmail.com',
      'noHp': '082188776655',
      'alamat': 'Jl. HOS Cokroaminoto No. 30, Jambi',
      'tanggalLahir': '14 Januari 1990',
      'jenisKelamin': 'Perempuan',
      'umur': '35 Tahun',
      'riwayat': 'Mengajar selama 7 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Budi Santoso M.Kom',
      'nip': '1357924680',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Artificial Intelligence',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Institut Teknologi Sepuluh Nopember',
      'email': 'budi@gmail.com',
      'noHp': '081223344556',
      'alamat': 'Jl. Soekarno Hatta No. 15, Jambi',
      'tanggalLahir': '2 Februari 1984',
      'jenisKelamin': 'Laki-laki',
      'umur': '41 Tahun',
      'riwayat': 'Mengajar selama 12 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Fitri Amelia M.Pd',
      'nip': '2468135790',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Psikologi Pendidikan',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Andalas',
      'email': 'fitri@gmail.com',
      'noHp': '082144556677',
      'alamat': 'Jl. Kapt. Azhari No. 20, Jambi',
      'tanggalLahir': '10 Desember 1988',
      'jenisKelamin': 'Perempuan',
      'umur': '36 Tahun',
      'riwayat': 'Mengajar selama 9 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Dian Saputra M.Kom',
      'nip': '1597534862',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Data Science',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Diponegoro',
      'email': 'dian@gmail.com',
      'noHp': '081266778899',
      'alamat': 'Jl. Lintas Sumatera No. 10, Mendalo',
      'tanggalLahir': '17 Agustus 1987',
      'jenisKelamin': 'Laki-laki',
      'umur': '38 Tahun',
      'riwayat': 'Mengajar selama 10 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Rani Oktaviani M.Si',
      'nip': '2589631470',
      'jabatan': 'Dosen Luar Biasa',
      'bidang': 'Statistika Terapan',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'Universitas Sriwijaya',
      'email': 'rani@gmail.com',
      'noHp': '082177889900',
      'alamat': 'Jl. Depati Parbo No. 77, Kota Baru',
      'tanggalLahir': '8 Oktober 1991',
      'jenisKelamin': 'Perempuan',
      'umur': '34 Tahun',
      'riwayat': 'Mengajar selama 6 tahun di UIN STS Jambi',
    },
    {
      'nama': 'Hendra Wijaya Ph.D',
      'nip': '7539514862',
      'jabatan': 'Dosen Tetap',
      'bidang': 'Machine Learning & Big Data',
      'kampus': 'UIN STS Jambi',
      'lulusan': 'National University of Singapore',
      'email': 'hendra@gmail.com',
      'noHp': '081255667788',
      'alamat': 'Jl. Hayam Wuruk No. 88, Jambi',
      'tanggalLahir': '22 Mei 1982',
      'jenisKelamin': 'Laki-laki',
      'umur': '43 Tahun',
      'riwayat': 'Mengajar selama 15 tahun di UIN STS Jambi',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Dosen UIN STS Jambi',
            style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.red.shade700,
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: dosenList.length,
        itemBuilder: (context, index) {
          final dosen = dosenList[index];
          return Card(
            elevation: 5,
            margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.red.shade200,
                child: Text(
                  dosen['nama'][0],
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              title: Text(dosen['nama'],
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(dosen['bidang']),
              trailing: const Icon(Icons.arrow_forward_ios, size: 18),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DetailDosenPage(dosen: dosen),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class DetailDosenPage extends StatelessWidget {
  final Map<String, dynamic> dosen;

  const DetailDosenPage({super.key, required this.dosen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(dosen['nama']),
        backgroundColor: Colors.red.shade700,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Card(
          elevation: 6,
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 60,
                  backgroundColor: Colors.red.shade100,
                  child: Icon(Icons.person, size: 60, color: Colors.red.shade700),
                ),
                const SizedBox(height: 20),
                Text(
                  dosen['nama'],
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(dosen['jabatan'],
                    style: const TextStyle(fontSize: 16, color: Colors.black54)),
                const Divider(height: 30, thickness: 1),
                _buildRow(Icons.badge, 'NIP', dosen['nip']),
                _buildRow(Icons.school, 'Lulusan', dosen['lulusan']),
                _buildRow(Icons.work, 'Bidang Keahlian', dosen['bidang']),
                _buildRow(Icons.account_balance, 'Kampus', dosen['kampus']),
                _buildRow(Icons.email, 'Email', dosen['email']),
                _buildRow(Icons.phone, 'No. HP', dosen['noHp']),
                _buildRow(Icons.home, 'Alamat', dosen['alamat']),
                _buildRow(Icons.cake, 'Tanggal Lahir', dosen['tanggalLahir']),
                _buildRow(Icons.person, 'Jenis Kelamin', dosen['jenisKelamin']),
                _buildRow(Icons.access_time, 'Umur', dosen['umur']),
                _buildRow(Icons.timeline, 'Riwayat', dosen['riwayat']),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: Colors.red.shade700),
          const SizedBox(width: 10),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: const TextStyle(fontSize: 14, color: Colors.black87),
                children: [
                  TextSpan(
                    text: "$label: ",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  TextSpan(text: value),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}