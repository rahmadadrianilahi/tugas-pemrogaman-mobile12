import 'package:flutter/material.dart';

void main() {
  runApp(const FeedbackSurveyApp());
}

class FeedbackSurveyApp extends StatelessWidget {
  const FeedbackSurveyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Feedback & Survey App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      home: const FeedbackFormPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class FeedbackFormPage extends StatefulWidget {
  const FeedbackFormPage({super.key});

  @override
  State<FeedbackFormPage> createState() => _FeedbackFormPageState();
}

class _FeedbackFormPageState extends State<FeedbackFormPage> {
  // Controller untuk field teks
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _commentController = TextEditingController();

  // Nilai-nilai lain
  String _category = 'Produk';
  int _productSatisfaction = 3;
  int _serviceSatisfaction = 3;
  int _rating = 0;
  String _recommendation = 'Ya';
  bool _contactAgain = false;

  // Fungsi submit
  void _submitFeedback() {
    if (_nameController.text.isEmpty ||
        _emailController.text.isEmpty ||
        _phoneController.text.isEmpty ||
        _commentController.text.isEmpty ||
        _rating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mohon isi semua data dan beri rating!')),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FeedbackResultPage(
          name: _nameController.text,
          email: _emailController.text,
          phone: _phoneController.text,
          category: _category,
          productSatisfaction: _productSatisfaction,
          serviceSatisfaction: _serviceSatisfaction,
          recommendation: _recommendation,
          contactAgain: _contactAgain,
          comment: _commentController.text,
          rating: _rating,
        ),
      ),
    );
  }

  // Widget rating bintang
  Widget _buildStarRating() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        return IconButton(
          icon: Icon(
            index < _rating ? Icons.star : Icons.star_border,
            color: Colors.amber,
            size: 32,
          ),
          onPressed: () => setState(() => _rating = index + 1),
        );
      }),
    );
  }

  // Widget slider
  Widget _buildSlider(String label, int value, Function(double) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        Slider(
          value: value.toDouble(),
          min: 1,
          max: 5,
          divisions: 4,
          label: '$value',
          onChanged: onChanged,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        // Background gradient
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF1565C0), Color(0xFF42A5F5)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text(
                  '📝 Formulir Feedback & Survei',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Kami menghargai waktu Anda untuk memberikan masukan agar layanan kami semakin baik.',
                  style: TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),

                // Card Form
                Card(
                  elevation: 10,
                  color: Colors.white.withOpacity(0.95),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        TextField(
                          controller: _nameController,
                          decoration: const InputDecoration(
                            labelText: 'Nama',
                            prefixIcon: Icon(Icons.person),
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Email',
                            prefixIcon: Icon(Icons.email),
                          ),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: _phoneController,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(
                            labelText: 'Nomor Telepon',
                            prefixIcon: Icon(Icons.phone),
                          ),
                        ),
                        const SizedBox(height: 16),
                        DropdownButtonFormField<String>(
                          value: _category,
                          decoration: const InputDecoration(
                            labelText: 'Kategori Feedback',
                            prefixIcon: Icon(Icons.category),
                          ),
                          items: const [
                            DropdownMenuItem(
                                value: 'Produk', child: Text('Produk')),
                            DropdownMenuItem(
                                value: 'Pelayanan', child: Text('Pelayanan')),
                            DropdownMenuItem(
                                value: 'Aplikasi', child: Text('Aplikasi')),
                            DropdownMenuItem(
                                value: 'Lainnya', child: Text('Lainnya')),
                          ],
                          onChanged: (value) =>
                              setState(() => _category = value!),
                        ),
                        const SizedBox(height: 20),

                        _buildSlider(
                            'Kepuasan terhadap produk', _productSatisfaction,
                                (val) {
                              setState(() => _productSatisfaction = val.toInt());
                            }),
                        _buildSlider(
                            'Kepuasan terhadap pelayanan', _serviceSatisfaction,
                                (val) {
                              setState(() => _serviceSatisfaction = val.toInt());
                            }),

                        const SizedBox(height: 16),
                        const Text(
                          'Apakah Anda akan merekomendasikan kami ke orang lain?',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Radio<String>(
                              value: 'Ya',
                              groupValue: _recommendation,
                              onChanged: (val) =>
                                  setState(() => _recommendation = val!),
                            ),
                            const Text('Ya'),
                            Radio<String>(
                              value: 'Tidak',
                              groupValue: _recommendation,
                              onChanged: (val) =>
                                  setState(() => _recommendation = val!),
                            ),
                            const Text('Tidak'),
                          ],
                        ),

                        const SizedBox(height: 8),
                        SwitchListTile(
                          title: const Text('Apakah kami boleh menghubungi Anda kembali?'),
                          value: _contactAgain,
                          onChanged: (val) => setState(() => _contactAgain = val),
                        ),

                        const SizedBox(height: 10),
                        TextField(
                          controller: _commentController,
                          maxLines: 3,
                          decoration: const InputDecoration(
                            labelText: 'Komentar tambahan',
                            hintText: 'Tuliskan saran atau pengalaman Anda...',
                            prefixIcon: Icon(Icons.comment),
                          ),
                        ),
                        const SizedBox(height: 20),

                        const Text('Beri Rating:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        _buildStarRating(),
                        const SizedBox(height: 25),

                        ElevatedButton.icon(
                          onPressed: _submitFeedback,
                          icon: const Icon(Icons.send),
                          label: const Text('Kirim Feedback'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueAccent,
                            foregroundColor: Colors.white,
                            minimumSize: const Size(double.infinity, 50),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class FeedbackResultPage extends StatelessWidget {
  final String name;
  final String email;
  final String phone;
  final String category;
  final int productSatisfaction;
  final int serviceSatisfaction;
  final String recommendation;
  final bool contactAgain;
  final String comment;
  final int rating;

  const FeedbackResultPage({
    super.key,
    required this.name,
    required this.email,
    required this.phone,
    required this.category,
    required this.productSatisfaction,
    required this.serviceSatisfaction,
    required this.recommendation,
    required this.contactAgain,
    required this.comment,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    final String tanggal =
        '${DateTime.now().day}-${DateTime.now().month}-${DateTime.now().year}';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hasil Feedback'),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF42A5F5), Color(0xFF1E88E5)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Card(
            color: Colors.white.withOpacity(0.95),
            margin: const EdgeInsets.all(20),
            elevation: 10,
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: ListView(
                shrinkWrap: true,
                children: [
                  Text('📅 Tanggal: $tanggal',
                      style: const TextStyle(fontSize: 16)),
                  const Divider(),
                  Text('👤 Nama: $name', style: const TextStyle(fontSize: 18)),
                  Text('📧 Email: $email', style: const TextStyle(fontSize: 18)),
                  Text('📱 Telepon: $phone',
                      style: const TextStyle(fontSize: 18)),
                  Text('🏷️ Kategori: $category',
                      style: const TextStyle(fontSize: 18)),
                  const SizedBox(height: 10),
                  Text('⭐ Kepuasan Produk: $productSatisfaction / 5'),
                  Text('💼 Kepuasan Pelayanan: $serviceSatisfaction / 5'),
                  Text('👍 Rekomendasi: $recommendation'),
                  Text('📞 Diizinkan Dihubungi: ${contactAgain ? 'Ya' : 'Tidak'}'),
                  const SizedBox(height: 10),
                  Text('💬 Komentar: $comment',
                      style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 15),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      5,
                          (index) => Icon(
                        index < rating ? Icons.star : Icons.star_border,
                        color: Colors.amber,
                        size: 30,
                      ),
                    ),
                  ),
                  const SizedBox(height: 25),
                  ElevatedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back),
                    label: const Text('Kembali ke Form'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
