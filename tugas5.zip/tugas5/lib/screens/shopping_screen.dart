import 'package:flutter/material.dart';
import '../models/shopping_item.dart';
import '../services/storage_service.dart';
import '../widgets/shopping_card.dart';

class ShoppingScreen extends StatefulWidget {
  const ShoppingScreen({super.key});

  @override
  State<ShoppingScreen> createState() => _ShoppingScreenState();
}

class _ShoppingScreenState extends State<ShoppingScreen> {
  final TextEditingController nameController = TextEditingController();
  int qty = 1;
  String category = "Makanan";

  List<ShoppingItem> items = [];
  int filter = 0; // 0 semua, 1 belum, 2 sudah

  final storage = StorageService();

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    items = await storage.loadShopping();
    setState(() {});
  }

  void addItem() {
    if (nameController.text.isEmpty) return;

    items.add(ShoppingItem(
      name: nameController.text,
      qty: qty,
      category: category,
      bought: false,
    ));

    nameController.clear();
    qty = 1;

    storage.saveShopping(items);
    setState(() {});
  }

  void toggle(ShoppingItem item) {
    item.bought = !item.bought;
    storage.saveShopping(items);
    setState(() {});
  }

  void delete(ShoppingItem item) {
    items.remove(item);
    storage.saveShopping(items);
    setState(() {});
  }

  List<ShoppingItem> get filtered {
    if (filter == 1) return items.where((e) => !e.bought).toList();
    if (filter == 2) return items.where((e) => e.bought).toList();
    return items;
  }

  @override
  Widget build(BuildContext context) {
    int total = items.length;
    int bought = items.where((e) => e.bought).length;
    int notBought = total - bought;

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: nameController,
                decoration: const InputDecoration(hintText: "Nama item..."),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 60,
              child: TextField(
                keyboardType: TextInputType.number,
                onChanged: (v) => qty = int.tryParse(v) ?? 1,
                decoration: const InputDecoration(),
              ),
            ),
            const SizedBox(width: 8),
            DropdownButton(
              value: category,
              items: ["Makanan", "Minuman", "Elektronik", "Lainnya"]
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => setState(() => category = v!),
            ),
            ElevatedButton(onPressed: addItem, child: const Text("Tambah"))
          ],
        ),

        // Summary
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            summaryBox("Total Item", total, Colors.blue),
            summaryBox("Sudah Dibeli", bought, Colors.green),
            summaryBox("Belum Dibeli", notBought, Colors.orange),
          ],
        ),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            filterButton(0, "Semua"),
            filterButton(1, "Belum Dibeli"),
            filterButton(2, "Sudah Dibeli"),
          ],
        ),

        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text("Belum ada item belanja"))
              : ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (_, i) => ShoppingCard(
              item: filtered[i],
              onDelete: delete,
              onToggle: toggle,
            ),
          ),
        ),
      ],
    );
  }

  Widget summaryBox(String title, int value, Color color) {
    return Container(
      margin: const EdgeInsets.all(6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text("$value",
              style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 20, color: color)),
          Text(title),
        ],
      ),
    );
  }

  Widget filterButton(int val, String label) {
    bool active = filter == val;
    return Padding(
        padding: const EdgeInsets.all(4.0),
        child: Elevated
