import 'package:flutter/material.dart';
import 'todo_screen.dart';
import 'shopping_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Aplikasi Tugas & Belanja")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: Text("Todo List"),
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => TodoScreen()));
              },
            ),
            ElevatedButton(
              child: Text("Daftar Belanja"),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => ShoppingScreen()));
              },
            ),
          ],
        ),
      ),
    );
  }
}
