import 'package:flutter/material.dart';
import '../models/todo_item.dart';
import '../services/storage_service.dart';
import '../widgets/todo_card.dart';

class TodoScreen extends StatefulWidget {
  const TodoScreen({super.key});

  @override
  State<TodoScreen> createState() => _TodoScreenState();
}

class _TodoScreenState extends State<TodoScreen> {
  final TextEditingController controller = TextEditingController();
  List<TodoItem> todos = [];
  int filter = 0; // 0: Semua, 1: Belum, 2: Selesai

  final storage = StorageService();

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    todos = await storage.loadTodos();
    setState(() {});
  }

  void addTodo() {
    if (controller.text.isEmpty) return;

    todos.add(TodoItem(
      title: controller.text,
      isDone: false,
    ));

    controller.clear();
    storage.saveTodos(todos);
    setState(() {});
  }

  void toggle(TodoItem item) {
    item.isDone = !item.isDone;
    storage.saveTodos(todos);
    setState(() {});
  }

  void delete(TodoItem item) {
    todos.remove(item);
    storage.saveTodos(todos);
    setState(() {});
  }

  List<TodoItem> get filtered {
    if (filter == 1) return todos.where((e) => !e.isDone).toList();
    if (filter == 2) return todos.where((e) => e.isDone).toList();
    return todos;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // input
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: "Tambah todo baru...",
                ),
              ),
            ),
            ElevatedButton(
              onPressed: addTodo,
              child: const Text("Tambah"),
            )
          ],
        ),

        // filter
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            filterButton(0, "Semua"),
            filterButton(1, "Belum"),
            filterButton(2, "Selesai"),
          ],
        ),

        const SizedBox(height: 10),

        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text("Belum ada todo"))
              : ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (_, i) => TodoCard(
              item: filtered[i],
              onDelete: delete,
              onToggle: toggle,
            ),
          ),
        )
      ],
    );
  }

  Widget filterButton(int val, String text) {
    bool active = filter == val;
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: ElevatedButton(
        onPressed: () => setState(() => filter = val),
        style: ElevatedButton.styleFrom(
          backgroundColor: active ? Colors.purple : Colors.grey[300],
        ),
        child: Text(text),
      ),
    );
  }
}
