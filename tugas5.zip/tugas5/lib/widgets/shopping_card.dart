import 'package:flutter/material.dart';
import '../models/shopping_item.dart';

class ShoppingCard extends StatelessWidget {
  final ShoppingItem item;
  final VoidCallback onToggle;
  final VoidCallback onDelete;

  const ShoppingCard({
    super.key,
    required this.item,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Checkbox(
          value: item.isBought,
          onChanged: (_) => onToggle(),
        ),
        title: Text("${item.name} (${item.quantity})"),
        subtitle: Text(item.category),
        trailing: IconButton(
          icon: Icon(Icons.delete),
          onPressed: onDelete,
        ),
      ),
    );
  }
}
