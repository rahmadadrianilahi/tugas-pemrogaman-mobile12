import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/todo_item.dart';
import '../models/shopping_item.dart';

class StorageService {
  static const todoKey = "todos";
  static const shopKey = "shopping_items";

  // ------------------- TODO -------------------
  Future<List<TodoItem>> loadTodos() async {
    final prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString(todoKey);
    if (data == null) return [];
    List decoded = jsonDecode(data);
    return decoded.map((e) => TodoItem.fromJson(e)).toList();
  }

  Future<void> saveTodos(List<TodoItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    String json = jsonEncode(items.map((e) => e.toJson()).toList());
    await prefs.setString(todoKey, json);
  }

  // ------------------- SHOPPING -------------------
  Future<List<ShoppingItem>> loadShopping() async {
    final prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString(shopKey);
    if (data == null) return [];
    List decoded = jsonDecode(data);
    return decoded.map((e) => ShoppingItem.fromJson(e)).toList();
  }

  Future<void> saveShopping(List<ShoppingItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    String json = jsonEncode(items.map((e) => e.toJson()).toList());
    await prefs.setString(shopKey, json);
  }
}
