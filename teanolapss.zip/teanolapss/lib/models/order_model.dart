class OrderModel {
  final int? id;
  final String namaPemesan;
  final String namaTeh;
  final int jumlah;
  final int totalHarga;
  final String tanggal;

  OrderModel({
    this.id,
    required this.namaPemesan,
    required this.namaTeh,
    required this.jumlah,
    required this.totalHarga,
    required this.tanggal,
  });

  // Convert Object ke Map (untuk simpan ke SQLite)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama_pemesan': namaPemesan,
      'nama_teh': namaTeh,
      'jumlah': jumlah,
      'total_harga': totalHarga,
      'tanggal': tanggal,
    };
  }

  // Convert Map dari SQLite ke Object
  factory OrderModel.fromMap(Map<String, dynamic> map) {
    return OrderModel(
      id: map['id'],
      namaPemesan: map['nama_pemesan'],
      namaTeh: map['nama_teh'],
      jumlah: map['jumlah'],
      totalHarga: map['total_harga'],
      tanggal: map['tanggal'],
    );
  }
}