class TeaModel {
  final int id;
  final String nama;
  final int harga;
  final String deskripsi;
  final String gambarUrl;

  TeaModel({
    required this.id,
    required this.nama,
    required this.harga,
    this.deskripsi = '',
    this.gambarUrl = 'https://placehold.co/600x400.png',
  });

  // Factory untuk membuat dari JSON (untuk API nanti)
  factory TeaModel.fromJson(Map<String, dynamic> json) {
    return TeaModel(
      id: json['id'] ?? 0,
      nama: json['nama'] ?? '',
      harga: json['harga'] ?? 0,
      deskripsi: json['deskripsi'] ?? '',
      gambarUrl: json['gambarUrl'] ?? 'https://placehold.co/600x400.png',
    );
  }

  // Method untuk convert ke JSON (untuk API nanti)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nama': nama,
      'harga': harga,
      'deskripsi': deskripsi,
      'gambarUrl': gambarUrl,
    };
  }

  // CopyWith untuk update data
  TeaModel copyWith({
    int? id,
    String? nama,
    int? harga,
    String? deskripsi,
    String? gambarUrl,
  }) {
    return TeaModel(
      id: id ?? this.id,
      nama: nama ?? this.nama,
      harga: harga ?? this.harga,
      deskripsi: deskripsi ?? this.deskripsi,
      gambarUrl: gambarUrl ?? this.gambarUrl,
    );
  }
}