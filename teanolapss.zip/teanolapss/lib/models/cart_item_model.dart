import 'tea_model.dart';

class CartItem {
  final String id;    // ID unik untuk baris di struk
  final TeaModel tea; // Produk yang dibeli (menggunakan TeaModel kamu)
  int quantity;       // Jumlah beli

  CartItem({
    required this.id,
    required this.tea,
    this.quantity = 1,
  });

  // Hitung total: harga (int) * quantity (int) -> hasil didouble-kan agar aman
  double get totalPrice => (tea.harga * quantity).toDouble();
}