class Note {
  final int? id; // Ubah jadi int dan boleh null (karena auto-increment)
  final String title;
  final String content;

  Note({this.id, required this.title, required this.content});

  // Dari Map (Database) ke Object Dart
  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      id: map['id'],
      title: map['title'],
      content: map['content'],
    );
  }

  // Dari Object Dart ke Map (Database)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'content': content,
    };
  }
}