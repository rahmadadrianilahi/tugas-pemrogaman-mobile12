import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/tea_provider.dart';
import '../providers/auth_provider.dart';
import '../widgets/custom_card.dart';
import 'detail_screen.dart';
import 'menu_screen.dart'; // IMPORT MENU SCREEN

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedCategoryIndex = 0;
  final List<String> _categories = ["🔥 Terpopuler", "🧋 Milk Tea", "🍵 Pure Tea", "🍋 Fruit Tea", "☕ Coffee"];

  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<TeaProvider>(context, listen: false).fetchTeas());
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final userFirstName = auth.username.split(' ')[0];

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: Consumer<TeaProvider>(
        builder: (context, provider, child) {
          return CustomScrollView(
            slivers: [
              // 1. APP BAR
              SliverAppBar(
                expandedHeight: 120.0,
                floating: true,
                pinned: true,
                elevation: 0,
                backgroundColor: Colors.green[700],
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(bottom: Radius.circular(25)),
                ),
                flexibleSpace: FlexibleSpaceBar(
                  titlePadding: const EdgeInsets.only(left: 20, bottom: 20),
                  title: Row(
                    children: [
                      CircleAvatar(
                        radius: 20,
                        backgroundColor: Colors.white,
                        backgroundImage: NetworkImage("https://ui-avatars.com/api/?name=${auth.username}&background=random"),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Halo, $userFirstName! 👋", style: const TextStyle(fontSize: 14, color: Colors.white70)),
                          const Text("Mau minum apa?", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                        ],
                      ),
                    ],
                  ),
                ),
                actions: [
                  Container(
                    margin: const EdgeInsets.only(right: 15, top: 10),
                    decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(12)
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.notifications_outlined, color: Colors.white),
                      onPressed: () {},
                    ),
                  ),
                ],
              ),

              // 2. SEARCH BAR & BANNER & KATEGORI
              SliverToBoxAdapter(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Search Bar
                    Transform.translate(
                      offset: const Offset(0, -25),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withValues(alpha: 0.08),
                                blurRadius: 15,
                                offset: const Offset(0, 5)
                            )
                          ],
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.search, color: Colors.green),
                            SizedBox(width: 10),
                            Text("Cari matcha, thai tea...", style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                      ),
                    ),

                    // Banner Promo - TAMBAHKAN BANNER MENU RESTORAN
                    SizedBox(
                      height: 160,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        children: [
                          // BANNER MENU RESTORAN - KLIK UNTUK KE MENU SCREEN
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => MenuScreen()),
                              );
                            },
                            child: _buildPromoBanner(
                                "Menu Restoran",
                                "Lihat Paket Menu",
                                Color(0xFFEC4899), // Pink
                                Icons.restaurant_menu
                            ),
                          ),
                          const SizedBox(width: 15),
                          _buildPromoBanner("Diskon UAS", "Dapatkan Nilai A+", Colors.green, Icons.school),
                          const SizedBox(width: 15),
                          _buildPromoBanner("Buy 1 Get 1", "Khusus Hari Ini", Colors.orange, Icons.local_offer),
                        ],
                      ),
                    ),

                    const SizedBox(height: 25),

                    // Kategori Menu
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: const Text("Kategori", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 40,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: _categories.length,
                        itemBuilder: (context, index) {
                          bool isSelected = _selectedCategoryIndex == index;
                          return GestureDetector(
                            onTap: () => setState(() => _selectedCategoryIndex = index),
                            child: Container(
                              margin: const EdgeInsets.only(right: 10),
                              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected ? Colors.green[700] : Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: isSelected ? null : Border.all(color: Colors.grey.shade300),
                              ),
                              child: Text(
                                _categories[index],
                                style: TextStyle(
                                  color: isSelected ? Colors.white : Colors.black87,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),

              // 3. GRID MENU
              provider.isLoading
                  ? const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: Colors.green)))
                  : provider.teas.isEmpty
                  ? const SliverFillRemaining(child: Center(child: Text("Data Kosong / Offline")))
                  : SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 20,
                    crossAxisSpacing: 15,
                    childAspectRatio: 0.72,
                  ),
                  delegate: SliverChildBuilderDelegate(
                        (context, index) {
                      final tea = provider.teas[index];
                      return CustomCard(
                        tea: tea,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailScreen(tea: tea),
                            ),
                          );
                        },
                      );
                    },
                    childCount: provider.teas.length,
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 50)),
            ],
          );
        },
      ),
    );
  }

  Widget _buildPromoBanner(String title, String subtitle, Color color, IconData icon) {
    return Container(
      width: 280,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [color.withValues(alpha: 0.8), color]
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: color.withValues(alpha: 0.3),
              blurRadius: 10,
              offset: const Offset(0, 5)
          )
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(5)),
                  child: const Text("PROMO", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 5),
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          Icon(icon, size: 60, color: Colors.white.withValues(alpha: 0.2)),
        ],
      ),
    );
  }
}