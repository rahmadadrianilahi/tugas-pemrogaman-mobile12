import 'package:flutter/material.dart';
import '../models/tea_model.dart';
import 'form_order_screen.dart';

class DetailScreen extends StatelessWidget {
  final TeaModel tea;

  const DetailScreen({super.key, required this.tea});

  @override
  Widget build(BuildContext context) {
    // Mengambil tinggi layar
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.white,
      // Stack untuk menumpuk Gambar di belakang & Konten di depan
      body: Stack(
        children: [
          // 1. GAMBAR PRODUK BESAR (BACKGROUND)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: size.height * 0.5, // Setengah layar
            child: Hero(
              tag: tea.nama,
              child: Image.network(
                tea.gambarUrl,
                fit: BoxFit.cover,
                errorBuilder: (ctx, _, __) => Container(color: Colors.grey[300]),
              ),
            ),
          ),

          // Tombol Back & Share di atas gambar
          Positioned(
            top: 50,
            left: 20,
            right: 20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCircleIcon(Icons.arrow_back, () => Navigator.pop(context)),
                _buildCircleIcon(Icons.favorite_border, () {}), // Dummy wishlist
              ],
            ),
          ),

          // 2. PANEL INFORMASI (SLIDING UP SHEET)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: size.height * 0.55, // Panel menutupi 55% layar
              padding: const EdgeInsets.fromLTRB(25, 30, 25, 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, -5))
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Garis Handle Kecil
                  Center(
                    child: Container(
                      width: 50, height: 5,
                      decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  const SizedBox(height: 25),

                  // Label Kategori (Badge)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.orange[50],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      "🔥 Paling Laris",
                      style: TextStyle(color: Colors.orange[800], fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Judul & Harga
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          tea.nama,
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, height: 1.1),
                          maxLines: 2,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        "Rp ${tea.harga}",
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green[700]),
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  // Info Rating (Dummy biar keren)
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 20),
                      const SizedBox(width: 5),
                      const Text("4.8", style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(width: 5),
                      Text("(1.2rb+ Terjual)", style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                      const Spacer(),
                      const Icon(Icons.access_time, size: 16, color: Colors.grey),
                      const SizedBox(width: 5),
                      const Text("15 Menit", style: TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ),

                  const SizedBox(height: 20),
                  const Divider(),
                  const SizedBox(height: 15),

                  // Deskripsi
                  const Text("Tentang Menu", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 8),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Text(
                        tea.deskripsi,
                        style: TextStyle(color: Colors.grey[600], height: 1.6, fontSize: 14),
                      ),
                    ),
                  ),

                  // 3. TOMBOL PESAN (Floating)
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => FormOrderScreen(tea: tea),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[700],
                        elevation: 5,
                        shadowColor: Colors.green.withOpacity(0.4),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("PESAN SEKARANG", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                          SizedBox(width: 10),
                          Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 20),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper untuk tombol bulat kecil di atas gambar
  Widget _buildCircleIcon(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.9), // Transparan sedikit
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10)],
        ),
        child: Icon(icon, color: Colors.black87, size: 22),
      ),
    );
  }
}