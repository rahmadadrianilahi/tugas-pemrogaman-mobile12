import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  void _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);
    await Future.delayed(const Duration(seconds: 1, milliseconds: 500));

    if (!mounted) return;

    await Provider.of<AuthProvider>(context, listen: false).login(
      _usernameController.text,
      _passwordController.text,
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFFF2F5F8),
      body: SingleChildScrollView(
        child: SizedBox(
          height: size.height,
          child: Stack(
            children: [
              // ============================================================
              // BAGIAN 1: HEADER GAMBAR DENGAN OVERLAY GELAP (YANG DIUBAH)
              // ============================================================
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                height: size.height * 0.45, // Tinggi 45% layar
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // A. Layer Foto Background (Melengkung di bawah)
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(40)),
                      child: Image.network(
                        // Foto estetik suasana teh (agak gelap biar tulisan terbaca)
                        "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=800&q=80",
                        fit: BoxFit.cover,
                        errorBuilder: (ctx, _, __) => Container(color: Colors.green[800]), // Warna cadangan jika internet mati
                      ),
                    ),
                    // B. Layer Overlay Gelap Transparan (Agar teks putih terbaca)
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4), // Gelap 40%
                        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(40)),
                      ),
                    ),
                    // C. Konten Teks & Ikon di atas gambar
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.emoji_food_beverage_rounded, size: 60, color: Colors.white),
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          "Teanol Apps",
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          "Aroma ketenangan di setiap tegukan",
                          style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14),
                        ),
                        const SizedBox(height: 50), // Spasi agar tidak tertutup kartu
                      ],
                    ),
                  ],
                ),
              ),
              // ============================================================

              // 2. FLOATING CARD FORM (TIDAK BERUBAH)
              Positioned(
                top: size.height * 0.35,
                left: 20,
                right: 20,
                child: Container(
                  padding: const EdgeInsets.all(30),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(25),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Selamat Datang!",
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
                        ),
                        const SizedBox(height: 5),
                        const Text("Silakan masuk untuk mulai memesan.", style: TextStyle(color: Colors.grey)),
                        const SizedBox(height: 30),

                        _buildModernInput(
                          controller: _usernameController,
                          hint: "Username / Nama Anda",
                          icon: Icons.person_outline_rounded,
                          validator: (val) => val!.isEmpty ? "Nama wajib diisi" : null,
                        ),
                        const SizedBox(height: 20),

                        _buildModernInput(
                          controller: _passwordController,
                          hint: "Password",
                          icon: Icons.lock_outline_rounded,
                          isPassword: true,
                          validator: (val) => val!.length < 3 ? "Password terlalu pendek" : null,
                        ),
                        const SizedBox(height: 40),

                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              // Gradient tombol tetap hijau agar senada
                              gradient: LinearGradient(
                                colors: [Colors.green.shade700, Colors.green.shade500],
                              ),
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.green.withOpacity(0.3),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                ),
                              ],
                            ),
                            child: ElevatedButton(
                              onPressed: _isLoading ? null : _submit,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                              ),
                              child: _isLoading
                                  ? const SizedBox(
                                height: 25, width: 25,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                              )
                                  : const Text(
                                "MASUK SEKARANG",
                                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModernInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool isPassword = false,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.grey[400]),
        prefixIcon: Icon(icon, color: Colors.green[600]),
        filled: true,
        fillColor: Colors.grey[50],
        contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.green, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(color: Colors.red),
        ),
      ),
      validator: validator,
    );
  }
}