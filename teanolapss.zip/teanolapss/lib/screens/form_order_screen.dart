import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../models/tea_model.dart';
import '../models/order_model.dart';
import '../providers/order_provider.dart';

class FormOrderScreen extends StatefulWidget {
  final TeaModel? tea;

  const FormOrderScreen({super.key, this.tea});

  @override
  State<FormOrderScreen> createState() => _FormOrderScreenState();
}

class _FormOrderScreenState extends State<FormOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _namaController = TextEditingController();
  final _catatanController = TextEditingController();

  int _jumlahBeli = 1;
  int _totalBayar = 0;
  String _selectedPayment = 'Cash'; // Default Cash

  @override
  void initState() {
    super.initState();
    if (widget.tea != null) {
      _totalBayar = widget.tea!.harga;
    }
  }

  void _increment() {
    setState(() {
      _jumlahBeli++;
      _updateTotal();
    });
  }

  void _decrement() {
    if (_jumlahBeli > 1) {
      setState(() {
        _jumlahBeli--;
        _updateTotal();
      });
    }
  }

  void _updateTotal() {
    _totalBayar = (widget.tea?.harga ?? 0) * _jumlahBeli;
  }

  @override
  void dispose() {
    _namaController.dispose();
    _catatanController.dispose();
    super.dispose();
  }

  // --- LOGIKA BARU UNTUK TOMBOL PESAN ---
  void _handlePesanButton() {
    // 1. Cek Validasi Form Dulu
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('⚠️ Nama Pemesan Wajib Diisi!'),
          backgroundColor: Colors.red[700],
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    // 2. Cek Metode Pembayaran
    if (_selectedPayment == 'QRIS') {
      // Jika QRIS, Tampilkan Pop-up Barcode Dulu
      _showQRISDialog();
    } else {
      // Jika Cash, Langsung Simpan
      _processOrderToDatabase();
    }
  }

  // --- POP-UP SIMULASI QRIS ---
  void _showQRISDialog() {
    showDialog(
      context: context,
      barrierDismissible: false, // User gabisa tutup sembarangan
      builder: (ctx) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          contentPadding: const EdgeInsets.all(20),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Scan untuk Bayar", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 10),
              const Text("Silakan scan QRIS di bawah ini:"),
              const SizedBox(height: 20),
              // Gambar QR Code Dummy
              Container(
                width: 200, height: 200,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Image.network(
                  "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=BayarTeanol$_totalBayar",
                  fit: BoxFit.cover,
                  loadingBuilder: (ctx, child, loading) {
                    if (loading == null) return child;
                    return const Center(child: CircularProgressIndicator());
                  },
                ),
              ),
              const SizedBox(height: 20),
              Text("Total: Rp $_totalBayar", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Colors.green)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(ctx); // Tutup Dialog
                    _processOrderToDatabase(); // Lanjut Simpan
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[700],
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text("SUDAH BAYAR", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // --- PROSES SIMPAN KE DATABASE ---
  void _processOrderToDatabase() {
    final provider = Provider.of<OrderProvider>(context, listen: false);
    final tanggal = DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now());

    // Gabungkan Nama Teh dengan Catatan & Info Pembayaran
    // Biar info QRIS-nya terekam di history tanpa ubah database
    String namaTehFinal = widget.tea?.nama ?? 'Unknown';
    String catatanTambahan = "";

    if (_catatanController.text.isNotEmpty) {
      catatanTambahan += "Note: ${_catatanController.text}. ";
    }
    // Tempelkan info metode bayar
    catatanTambahan += "[Bayar: $_selectedPayment]";

    namaTehFinal += " ($catatanTambahan)";

    final newOrder = OrderModel(
      namaPemesan: _namaController.text,
      namaTeh: namaTehFinal,
      jumlah: _jumlahBeli,
      totalHarga: _totalBayar,
      tanggal: tanggal,
    );

    provider.addOrder(newOrder).then((_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('✅ Pesanan Berhasil!'),
          backgroundColor: Colors.green[800],
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.popUntil(context, (route) => route.isFirst);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.tea == null) return const Scaffold(body: Center(child: Text("Error")));

    return Scaffold(
      backgroundColor: const Color(0xFFF2F5F8),
      body: CustomScrollView(
        slivers: [
          // Header Gambar
          SliverAppBar(
            expandedHeight: 280.0,
            pinned: true,
            backgroundColor: Colors.green[700],
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.black),
                  onPressed: () => Navigator.pop(context),
                ),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(
                    tag: widget.tea!.nama,
                    child: Image.network(
                      widget.tea!.gambarUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (ctx, _, __) => Container(color: Colors.grey),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Konten Form
          SliverToBoxAdapter(
            child: Transform.translate(
              offset: const Offset(0, -20),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                ),
                padding: const EdgeInsets.all(24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(child: Container(width: 50, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(10)))),
                      const SizedBox(height: 25),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(child: Text(widget.tea!.nama, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
                          Text("Rp ${widget.tea!.harga}", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green[700])),
                        ],
                      ),
                      const Divider(height: 40),

                      const Text("Mau pesan berapa?", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 15),
                      Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(15),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildCounterButton(Icons.remove, _decrement),
                            Text("$_jumlahBeli Porsi", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            _buildCounterButton(Icons.add, _increment, isPlus: true),
                          ],
                        ),
                      ),
                      const SizedBox(height: 25),

                      const Text("Data Pemesan", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 10),
                      _buildTextField(controller: _namaController, hint: "Nama Anda (Wajib)", icon: Icons.person_outline, validator: (val) => val!.isEmpty ? 'Nama harus diisi' : null),
                      const SizedBox(height: 15),
                      _buildTextField(controller: _catatanController, hint: "Catatan (Opsional: Es dikit...)", icon: Icons.edit_note, maxLines: 2),
                      const SizedBox(height: 25),

                      const Text("Metode Pembayaran", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _buildPaymentOption("Cash", Icons.money),
                          const SizedBox(width: 15),
                          _buildPaymentOption("QRIS", Icons.qr_code_scanner),
                        ],
                      ),

                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),

      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 20, offset: const Offset(0, -5))],
          borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Total Tagihan", style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  Text("Rp $_totalBayar", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.green[800])),
                ],
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Container(
                height: 55,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.green[400]!, Colors.green[700]!]),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 5))],
                ),
                child: ElevatedButton(
                  onPressed: _handlePesanButton, // Panggil logika baru di sini
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  child: const Text("PESAN", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCounterButton(IconData icon, VoidCallback onTap, {bool isPlus = false}) {
    return Material(
      color: isPlus ? Colors.green : Colors.white,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 45, height: 45,
          alignment: Alignment.center,
          decoration: BoxDecoration(border: isPlus ? null : Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: isPlus ? Colors.white : Colors.black, size: 20),
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String hint, required IconData icon, int maxLines = 1, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: Colors.green[700]),
        filled: true, fillColor: Colors.grey[50],
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Colors.green)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: Colors.grey[200]!)),
      ),
      validator: validator,
    );
  }

  Widget _buildPaymentOption(String label, IconData icon) {
    bool isSelected = _selectedPayment == label;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedPayment = label),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? Colors.green.withOpacity(0.1) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: isSelected ? Colors.green : Colors.grey[300]!, width: isSelected ? 2 : 1),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? Colors.green[700] : Colors.grey),
              const SizedBox(height: 5),
              Text(label, style: TextStyle(fontWeight: FontWeight.bold, color: isSelected ? Colors.green[700] : Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}