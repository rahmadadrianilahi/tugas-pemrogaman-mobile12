import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/order_provider.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() =>
        Provider.of<OrderProvider>(context, listen: false).fetchOrders());
  }

  // --- FUNGSI MUNCUL POPUP EDIT ---
  void _showEditDialog(BuildContext context, var order) {
    final quantityController = TextEditingController(text: order.jumlah.toString());

    // Hitung harga satuan (Total Harga / Jumlah Lama)
    int hargaSatuan = (order.totalHarga / order.jumlah).round();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Edit Pesanan"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Ubah jumlah pesanan untuk:\n${order.namaTeh}", style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            TextField(
              controller: quantityController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Jumlah Baru",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.shopping_bag),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Batal")),
          ElevatedButton(
            onPressed: () {
              int? jumlahBaru = int.tryParse(quantityController.text);
              if (jumlahBaru != null && jumlahBaru > 0) {
                // Hitung total harga baru
                int totalBaru = hargaSatuan * jumlahBaru;

                // Panggil Provider Update
                Provider.of<OrderProvider>(context, listen: false)
                    .updateOrder(order.id!, jumlahBaru, totalBaru);

                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("✅ Data berhasil diupdate!")));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text("Simpan", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text("Riwayat Transaksi", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Consumer<OrderProvider>(
        builder: (context, provider, child) {
          if (provider.orders.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long_rounded, size: 80, color: Colors.grey[300]),
                  const SizedBox(height: 15),
                  Text("Belum ada riwayat", style: TextStyle(color: Colors.grey[500])),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: provider.orders.length,
            itemBuilder: (context, index) {
              final order = provider.orders[index];

              return Container(
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4))
                  ],
                  border: Border(left: BorderSide(color: Colors.green[400]!, width: 5)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      // Header: Tanggal & Status
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(order.tanggal, style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: Colors.green[50], borderRadius: BorderRadius.circular(6)),
                            child: Text("Selesai", style: TextStyle(color: Colors.green[800], fontSize: 10, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      ),
                      const Divider(),

                      // Isi: Detail Pesanan
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(color: Colors.green[50], shape: BoxShape.circle),
                            child: Icon(Icons.coffee, color: Colors.green[700]),
                          ),
                          const SizedBox(width: 15),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(order.namaTeh, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                const SizedBox(height: 5),
                                Text("Pemesan: ${order.namaPemesan}", style: const TextStyle(color: Colors.grey, fontSize: 13)),
                                Text("${order.jumlah} Porsi", style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          Text("Rp ${order.totalHarga}", style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green)),
                        ],
                      ),

                      const SizedBox(height: 15),

                      // --- TOMBOL AKSI CRUD (EDIT & DELETE) ---
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          // Tombol EDIT
                          OutlinedButton.icon(
                            onPressed: () => _showEditDialog(context, order),
                            icon: const Icon(Icons.edit, size: 16, color: Colors.orange),
                            label: const Text("Edit", style: TextStyle(color: Colors.orange)),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.orange),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                          const SizedBox(width: 10),

                          // Tombol DELETE
                          OutlinedButton.icon(
                            onPressed: () {
                              // Dialog Konfirmasi Hapus
                              showDialog(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                  title: const Text("Hapus?"),
                                  content: const Text("Yakin ingin menghapus riwayat ini?"),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Batal")),
                                    TextButton(
                                      onPressed: () {
                                        provider.deleteOrder(order.id!);
                                        Navigator.pop(ctx);
                                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("🗑️ Data dihapus")));
                                      },
                                      child: const Text("Hapus", style: TextStyle(color: Colors.red)),
                                    ),
                                  ],
                                ),
                              );
                            },
                            icon: const Icon(Icons.delete, size: 16, color: Colors.red),
                            label: const Text("Hapus", style: TextStyle(color: Colors.red)),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.red),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}