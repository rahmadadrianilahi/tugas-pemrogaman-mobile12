import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../models/tea_model.dart';
import '../providers/cart_provider.dart';

class CashierScreen extends StatefulWidget {
  const CashierScreen({super.key});

  @override
  State<CashierScreen> createState() => _CashierScreenState();
}

class _CashierScreenState extends State<CashierScreen> {
  final TextEditingController _paymentController = TextEditingController();
  int _uangDiterima = 0;

  // === DAFTAR 7 MENU DENGAN GAMBAR LOKAL ===
  final List<TeaModel> daftarMenu = [
    TeaModel(
        id: 1,
        nama: 'Original Thai Tea',
        harga: 15000,
        deskripsi: 'Teh Thailand Original',
        gambarUrl: 'assets/images/menu/GAMBAR1.jpg'
    ),
    TeaModel(
        id: 2,
        nama: 'Green Tea Latte',
        harga: 18000,
        deskripsi: 'Teh Hijau Susu Creamy',
        gambarUrl: 'assets/images/menu/GAMBAR2.jpg'
    ),
    TeaModel(
        id: 4,
        nama: 'Iced Coffee',
        harga: 17000,
        deskripsi: 'Kopi Susu Gula Aren',
        gambarUrl: 'assets/images/menu/GAMBAR4.jpg'
    ),
    TeaModel(
        id: 5,
        nama: 'Lemon Tea Fresh',
        harga: 14000,
        deskripsi: 'Teh Lemon Segar',
        gambarUrl: 'assets/images/menu/GAMBAR5.jpg'
    ),
    TeaModel(
        id: 8,
        nama: 'Mango Smoothie',
        harga: 20000,
        deskripsi: 'Mangga Asli Blender',
        gambarUrl: 'assets/images/menu/GAMBAR8.jpg'
    ),
    TeaModel(
        id: 9,
        nama: 'Blue Lagoon',
        harga: 16000,
        deskripsi: 'Soda Biru Segar',
        gambarUrl: 'assets/images/menu/GAMBAR9.jpg'
    ),
    TeaModel(
        id: 11,
        nama: 'Hot Cappuccino',
        harga: 18000,
        deskripsi: 'Kopi Panas Berbusa',
        gambarUrl: 'assets/images/menu/GAMBAR11.jpg'
    ),
  ];

  @override
  void initState() {
    super.initState();
    _paymentController.addListener(() {
      setState(() {
        String cleanText = _paymentController.text.replaceAll('.', '').replaceAll(',', '');
        _uangDiterima = int.tryParse(cleanText) ?? 0;
      });
    });
  }

  @override
  void dispose() {
    _paymentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mesin Kasir (POS)'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Row(
        children: [
          // --- BAGIAN KIRI: DAFTAR MENU ---
          Expanded(
            flex: 3,
            child: Container(
              color: Colors.grey[100],
              padding: const EdgeInsets.all(16),
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  childAspectRatio: 0.75,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                ),
                itemCount: daftarMenu.length,
                itemBuilder: (ctx, i) {
                  final menu = daftarMenu[i];
                  return GestureDetector(
                    onTap: () {
                      Provider.of<CartProvider>(context, listen: false).addItem(menu);

                      // Tampilkan snackbar konfirmasi
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('${menu.nama} ditambahkan ke keranjang'),
                          duration: const Duration(milliseconds: 800),
                          backgroundColor: Colors.green,
                        ),
                      );
                    },
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      clipBehavior: Clip.antiAlias,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(
                            child: Image.asset(
                              menu.gambarUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return Container(
                                  color: Colors.grey[300],
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.broken_image, color: Colors.grey[600], size: 50),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Gambar\nTidak Tersedia',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(12.0),
                            color: Colors.white,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  menu.nama,
                                  textAlign: TextAlign.center,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  currencyFormatter.format(menu.harga),
                                  style: TextStyle(color: Colors.red[700], fontWeight: FontWeight.bold, fontSize: 13),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // --- BAGIAN KANAN: STRUK & BAYAR ---
          Expanded(
            flex: 2,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(left: BorderSide(color: Colors.grey.shade200)),
              ),
              child: Consumer<CartProvider>(
                builder: (ctx, cart, child) {
                  int totalBelanja = cart.totalAmount.toInt();
                  int kembalian = _uangDiterima - totalBelanja;
                  bool uangKurang = _uangDiterima > 0 && _uangDiterima < totalBelanja;

                  return Column(
                    children: [
                      const Text("Struk Belanja", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      const Divider(thickness: 1.5),
                      Expanded(
                        child: cart.items.isEmpty
                            ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.shopping_cart_outlined, size: 80, color: Colors.grey[300]),
                              const SizedBox(height: 10),
                              const Text("Keranjang Kosong", style: TextStyle(color: Colors.grey, fontSize: 16)),
                            ],
                          ),
                        )
                            : ListView.separated(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          separatorBuilder: (ctx, i) => const Divider(height: 1),
                          itemCount: cart.items.length,
                          itemBuilder: (ctx, i) {
                            final item = cart.items.values.toList()[i];
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(item.tea.nama, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                              subtitle: Text("${item.quantity} x ${currencyFormatter.format(item.tea.harga)}"),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(currencyFormatter.format(item.totalPrice), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                                  IconButton(
                                    icon: const Icon(Icons.remove_circle, color: Colors.red),
                                    onPressed: () => cart.removeSingleItem(item.tea.id),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                      const Divider(thickness: 1.5),
                      const SizedBox(height: 10),

                      // Container Pembayaran
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                            color: Colors.grey[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade300)
                        ),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text("Total Tagihan:", style: TextStyle(fontSize: 16)),
                                Text(
                                  currencyFormatter.format(totalBelanja),
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            TextField(
                              controller: _paymentController,
                              keyboardType: TextInputType.number,
                              decoration: InputDecoration(
                                labelText: 'Uang Diterima (Rp)',
                                filled: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                                suffixIcon: IconButton(
                                  icon: const Icon(Icons.clear),
                                  onPressed: () {
                                    _paymentController.clear();
                                    setState(() => _uangDiterima = 0);
                                  },
                                ),
                                errorText: uangKurang ? "Uang Masih Kurang!" : null,
                                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                              ),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text("Kembalian:", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                Text(
                                  _uangDiterima > 0
                                      ? currencyFormatter.format(kembalian < 0 ? 0 : kembalian)
                                      : "-",
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: kembalian >= 0 ? Colors.green : Colors.grey
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            elevation: 2,
                          ),
                          onPressed: (cart.items.isEmpty || totalBelanja > _uangDiterima)
                              ? null
                              : () {
                            showDialog(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                title: const Column(
                                  children: [
                                    Icon(Icons.check_circle, color: Colors.green, size: 60),
                                    SizedBox(height: 10),
                                    Text("Pembayaran Berhasil!", textAlign: TextAlign.center),
                                  ],
                                ),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Divider(),
                                    _buildSummaryRow("Total Belanja", currencyFormatter.format(totalBelanja)),
                                    _buildSummaryRow("Tunai Diterima", currencyFormatter.format(_uangDiterima)),
                                    const Divider(),
                                    _buildSummaryRow("Kembalian", currencyFormatter.format(kembalian), isBold: true),
                                  ],
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      cart.clearCart();
                                      _paymentController.clear();
                                      setState(() => _uangDiterima = 0);
                                      Navigator.pop(ctx);
                                    },
                                    child: const Text("Tutup & Transaksi Baru", style: TextStyle(fontSize: 16)),
                                  )
                                ],
                              ),
                            );
                          },
                          child: const Text("BAYAR SEKARANG", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                        ),
                      )
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }
}