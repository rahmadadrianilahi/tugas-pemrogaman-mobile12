import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

// === IMPORT FILE PENDUKUNG ===
import 'models/tea_model.dart';
import 'providers/cart_provider.dart';
import 'providers/tea_provider.dart';
import 'screens/cashier_screen.dart';
import 'screens/menu_screen.dart'; // ✅ IMPORT MenuScreen

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => TeaProvider()..loadInitialData()), // ✅ TAMBAHKAN INI
      ],
      child: const MrRestoApp(),
    ),
  );
}

class MrRestoApp extends StatelessWidget {
  const MrRestoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mr. Resto POS',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF4A0072)),
        appBarTheme: AppBarTheme(
          backgroundColor: const Color(0xFF4A0072),
          foregroundColor: Colors.white,
          titleTextStyle: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
          iconTheme: const IconThemeData(color: Colors.white),
        ),
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: const DashboardPosPage(),
    );
  }
}

// ================= 1. DASHBOARD UTAMA =================

class DashboardPosPage extends StatelessWidget {
  const DashboardPosPage({super.key});

  void _navigasiKe(BuildContext context, Widget halaman) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => halaman));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // --- SIDEBAR KIRI ---
          Container(
            width: 260,
            decoration: BoxDecoration(
                color: Colors.white,
                border: Border(right: BorderSide(color: Colors.grey.shade200))
            ),
            child: Column(
              children: [
                Container(
                  height: 70,
                  alignment: Alignment.center,
                  color: const Color(0xFF4A0072),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.restaurant, color: Colors.white),
                      const SizedBox(width: 10),
                      Text("MR.RESTO APPS", style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: EdgeInsets.zero,
                    children: [
                      SidebarItem(title: "Home", icon: Icons.home, color: Colors.pinkAccent, onTap: () => _navigasiKe(context, const MenuScreen())), // ✅ GANTI KE MenuScreen
                      SidebarItem(title: "Data", icon: Icons.perm_contact_calendar, color: Colors.orangeAccent, onTap: () => _navigasiKe(context, const HalamanDataMaster())),
                      SidebarItem(title: "Menu & Stock", icon: Icons.restaurant_menu, color: Colors.blueAccent, onTap: () => _navigasiKe(context, const HalamanStokBarang())),
                      SidebarItem(title: "Inventori", icon: Icons.inventory_2, color: Colors.green, onTap: () => _navigasiKe(context, const HalamanInventoriMasuk())),
                      SidebarItem(title: "Transaksi", icon: Icons.shopping_cart, color: Colors.cyan, onTap: () => _navigasiKe(context, const HalamanRiwayatTransaksi())),
                      SidebarItem(title: "Penjualan", icon: Icons.point_of_sale, color: Colors.redAccent, onTap: () => _navigasiKe(context, const HalamanLaporanPenjualan())),
                      SidebarItem(title: "Keuangan", icon: Icons.monetization_on, color: Colors.teal, onTap: () => _navigasiKe(context, const HalamanKeuangan())),
                      const Divider(),
                      SidebarItem(title: "Settings", icon: Icons.settings, color: Colors.amber, onTap: () => _navigasiKe(context, const HalamanSettings())),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // --- KONTEN TENGAH ---
          Expanded(
            child: Column(
              children: [
                Container(
                  height: 70,
                  color: const Color(0xFF212121),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Dashboard Admin", style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                      const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person, color: Colors.black)),
                    ],
                  ),
                ),
                Expanded(
                  child: Center(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(25),
                            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.orange[50]),
                            child: Icon(Icons.storefront, size: 80, color: Colors.orange[800]),
                          ),
                          const SizedBox(height: 15),
                          Text("Mr.Resto Pos", style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.grey[800])),
                          const SizedBox(height: 40),
                          Wrap(
                            spacing: 25, runSpacing: 25, alignment: WrapAlignment.center,
                            children: [
                              MenuCard(title: "Cashier", icon: Icons.shopping_cart_checkout, color: Colors.red, onTap: () => _navigasiKe(context, const CashierScreen())),
                              MenuCard(title: "Kitchen", icon: Icons.kitchen, color: Colors.red, onTap: () => _navigasiKe(context, const HalamanDapur())),
                              MenuCard(title: "Booked", icon: Icons.event_seat, color: Colors.red, onTap: () => _navigasiKe(context, const HalamanReservasi())),
                              MenuCard(title: "Table", icon: Icons.table_restaurant, color: Colors.red, onTap: () => _navigasiKe(context, const HalamanDenahMeja())),
                              MenuCard(title: "Delivery", icon: Icons.delivery_dining, color: Colors.red, onTap: () => _navigasiKe(context, const HalamanDelivery())),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================= 2. HALAMAN DENGAN NAVIGASI KE DETAIL =================

// CATATAN: HalamanHomeMenu sudah diganti dengan MenuScreen dari screens/menu_screen.dart
// MenuScreen sudah memiliki fitur CRUD lengkap (Create, Read, Update, Delete)

// --- HALAMAN DATA MASTER (LIST -> HALAMAN SUB DATA) ---
class HalamanDataMaster extends StatelessWidget {
  const HalamanDataMaster({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Data Master"), backgroundColor: Colors.orangeAccent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildNavTile(context, Icons.category, "Kategori Produk", "Kelola Kategori", const DetailPage(title: "Master Kategori", content: "Daftar Kategori: Makanan Berat, Minuman, Dessert")),
          _buildNavTile(context, Icons.food_bank, "Data Produk", "Kelola 45 item menu", const DetailPage(title: "Master Produk", content: "Daftar Semua Produk:\n1. Nasi Goreng\n2. Mie Ayam\n3. Es Teh\n...")),
          _buildNavTile(context, Icons.table_bar, "Data Meja", "Kelola 12 meja", const DetailPage(title: "Master Meja", content: "Daftar Meja:\nMeja 1 (4 Kursi)\nMeja 2 (2 Kursi)\n...")),
          _buildNavTile(context, Icons.people, "Data Karyawan", "Absensi & Data", const DetailPage(title: "Master Karyawan", content: "Daftar Karyawan:\n1. Budi (Koki)\n2. Siti (Kasir)\n...")),
          _buildNavTile(context, Icons.payment, "Metode Pembayaran", "Bank & E-Wallet", const DetailPage(title: "Master Pembayaran", content: "Setting Metode Pembayaran:\n- Tunai\n- QRIS\n- Debit BCA")),
        ],
      ),
    );
  }

  Widget _buildNavTile(BuildContext context, IconData icon, String title, String sub, Widget halamanTujuan) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: Colors.orange[50], borderRadius: BorderRadius.circular(8)),
          child: Icon(icon, color: Colors.orange),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          // NAVIGASI KE HALAMAN BARU
          Navigator.push(context, MaterialPageRoute(builder: (context) => halamanTujuan));
        },
      ),
    );
  }
}

// --- HALAMAN INVENTORI (LIST -> DETAIL SURAT JALAN) ---
class HalamanInventoriMasuk extends StatelessWidget {
  const HalamanInventoriMasuk({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Barang Masuk (Supplier)"), backgroundColor: Colors.green),
      body: ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: 5,
        itemBuilder: (context, index) => Card(
          child: ListTile(
            leading: const CircleAvatar(backgroundColor: Colors.green, child: Icon(Icons.local_shipping, color: Colors.white)),
            title: Text("Supplier Sembako Jaya #${100+index}"),
            subtitle: const Text("Masuk: 12 Des 2025 - Status: Diterima"),
            trailing: const Icon(Icons.check_circle, color: Colors.green),
            onTap: () {
              // PINDAH KE HALAMAN DETAIL INVENTORI
              Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(title: "Detail Surat Jalan #${100+index}", content: "Barang Masuk:\n- Beras 50kg\n- Gula 20kg\n\nStatus: Diterima oleh Gudang")));
            },
          ),
        ),
      ),
    );
  }
}

// --- HALAMAN TRANSAKSI (LIST -> DETAIL STRUK) ---
class HalamanRiwayatTransaksi extends StatelessWidget {
  const HalamanRiwayatTransaksi({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Riwayat Transaksi"), backgroundColor: Colors.cyan),
      body: ListView.separated(
        padding: const EdgeInsets.all(10),
        itemCount: 8,
        separatorBuilder: (c, i) => const Divider(),
        itemBuilder: (ctx, i) => ListTile(
          leading: const Icon(Icons.receipt_long, color: Colors.cyan),
          title: Text("TRX-20251218-00$i", style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text("Total: Rp ${50 + (i*10)}.000"),
          trailing: Text("Lunas", style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.green)),
          onTap: () {
            // PINDAH KE HALAMAN DETAIL STRUK
            Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(title: "Struk Transaksi #00$i", content: "Detail Pesanan:\n2x Nasi Goreng\n1x Es Teh\n\nTotal: Rp ${50 + (i*10)}.000\nMetode: Tunai")));
          },
        ),
      ),
    );
  }
}

// ================= 3. HALAMAN UNIVERSAL UNTUK DETAIL =================
// Ini adalah halaman "Dummy" agar setiap kali diklik ada halaman baru yang muncul
class DetailPage extends StatelessWidget {
  final String title;
  final String content;

  const DetailPage({super.key, required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.grey[800], // Warna Netral
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(15),
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade300)
              ),
              child: Text(content, style: const TextStyle(fontSize: 16, height: 1.5)),
            ),
          ],
        ),
      ),
    );
  }
}

// ================= 4. FITUR OPERASIONAL & LAINNYA =================
// (Bagian ini tidak perlu berubah karena sudah interaktif sebelumnya)

class HalamanLaporanPenjualan extends StatelessWidget {
  const HalamanLaporanPenjualan({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Laporan Penjualan"), backgroundColor: Colors.redAccent),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.bar_chart, size: 100, color: Colors.redAccent),
            const SizedBox(height: 20),
            const Text("Grafik Penjualan Bulanan", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Container(height: 200, width: 300, color: Colors.red[50], child: const Center(child: Text("Chart Placeholder"))),
          ],
        ),
      ),
    );
  }
}

class HalamanKeuangan extends StatelessWidget {
  const HalamanKeuangan({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Laporan Laba Rugi"), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _cardKeuangan("Pemasukan Hari Ini", "Rp 5.250.000", Colors.green),
            const SizedBox(height: 15),
            _cardKeuangan("Pengeluaran Hari Ini", "Rp 1.500.000", Colors.red),
            const SizedBox(height: 15),
            _cardKeuangan("Keuntungan Bersih", "Rp 3.750.000", Colors.teal),
          ],
        ),
      ),
    );
  }
  Widget _cardKeuangan(String label, String nominal, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      width: double.infinity,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 16)),
        Text(nominal, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class HalamanSettings extends StatelessWidget {
  const HalamanSettings({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Pengaturan Aplikasi"), backgroundColor: Colors.amber),
      body: ListView(
        children: [
          SwitchListTile(value: true, onChanged: (v){}, title: const Text("Mode Gelap")),
          const Divider(),
          ListTile(
              title: const Text("Logout", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
              leading: const Icon(Icons.logout, color: Colors.red),
              onTap: (){ Navigator.pop(context); }
          ),
        ],
      ),
    );
  }
}

class HalamanStokBarang extends StatelessWidget {
  const HalamanStokBarang({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Stok Bahan Baku"), backgroundColor: Colors.blueAccent),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: DataTable(
          border: TableBorder.all(color: Colors.grey.shade300),
          columns: const [DataColumn(label: Text("Nama")), DataColumn(label: Text("Stok")), DataColumn(label: Text("Status"))],
          rows: const [
            DataRow(cells: [DataCell(Text("Beras")), DataCell(Text("50 Kg")), DataCell(Text("Aman"))]),
            DataRow(cells: [DataCell(Text("Ayam Potong")), DataCell(Text("12 Kg")), DataCell(Text("Restock!", style: TextStyle(color: Colors.red)))]),
          ],
        ),
      ),
    );
  }
}

// === FITUR INTERAKTIF (DAPUR, DLL) ===

class HalamanDapur extends StatefulWidget {
  const HalamanDapur({super.key});
  @override
  State<HalamanDapur> createState() => _HalamanDapurState();
}
class _HalamanDapurState extends State<HalamanDapur> {
  List<Map<String, dynamic>> pesananMeja = [
    {"meja": 1, "items": ["2x Nasi Goreng"], "status": "Masak"},
    {"meja": 2, "items": ["1x Mie Goreng"], "status": "Masak"},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Kitchen Display"), backgroundColor: Colors.orange),
      body: GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.2, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemCount: pesananMeja.length,
        itemBuilder: (ctx, i) => InkWell(
          onTap: () { setState(() { pesananMeja.removeAt(i); }); },
          child: Card(
            color: Colors.orange[50],
            child: Center(child: Text("Meja ${pesananMeja[i]['meja']}\n(Klik Selesai)", textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
          ),
        ),
      ),
    );
  }
}

class HalamanReservasi extends StatefulWidget {
  const HalamanReservasi({super.key});
  @override
  State<HalamanReservasi> createState() => _HalamanReservasiState();
}
class _HalamanReservasiState extends State<HalamanReservasi> {
  List<Map<String, String>> reservasi = [{"nama": "Bpk. Budi", "meja": "05"}];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Daftar Reservasi"), backgroundColor: Colors.purple),
      body: ListView.builder(
        itemCount: reservasi.length,
        itemBuilder: (context, index) => Card(
          child: ListTile(
            title: Text(reservasi[index]['nama']!),
            trailing: IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => setState(() => reservasi.removeAt(index))),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: (){ setState(() { reservasi.add({"nama": "Tamu Baru", "meja": "01"}); }); }, backgroundColor: Colors.purple, child: const Icon(Icons.add)),
    );
  }
}

class HalamanDenahMeja extends StatefulWidget {
  const HalamanDenahMeja({super.key});
  @override
  State<HalamanDenahMeja> createState() => _HalamanDenahMejaState();
}
class _HalamanDenahMejaState extends State<HalamanDenahMeja> {
  List<bool> status = [true, false, false, true, false, false];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Denah Meja"), backgroundColor: Colors.brown),
      body: GridView.count(crossAxisCount: 3, padding: const EdgeInsets.all(20), mainAxisSpacing: 20, crossAxisSpacing: 20,
        children: List.generate(6, (i) => InkWell(
          onTap: () => setState(() => status[i] = !status[i]),
          child: Container(color: status[i] ? Colors.red[100] : Colors.green[100], child: Center(child: Text("Meja ${i+1}\n${status[i]?'Isi':'Kosong'}", textAlign: TextAlign.center))),
        )),
      ),
    );
  }
}

class HalamanDelivery extends StatefulWidget {
  const HalamanDelivery({super.key});
  @override
  State<HalamanDelivery> createState() => _HalamanDeliveryState();
}
class _HalamanDeliveryState extends State<HalamanDelivery> {
  List<String> orders = ["ORD-001"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Delivery"), backgroundColor: Colors.indigo),
      body: ListView.builder(
        itemCount: orders.length,
        itemBuilder: (ctx, i) => Card(child: ListTile(title: Text(orders[i]), trailing: IconButton(icon: const Icon(Icons.delete), onPressed: () => setState(() => orders.removeAt(i))))),
      ),
      floatingActionButton: FloatingActionButton(onPressed: () => setState(() => orders.add("ORD-NEW")), backgroundColor: Colors.indigo, child: const Icon(Icons.add)),
    );
  }
}

// ================= WIDGET CUSTOM =================
class SidebarItem extends StatelessWidget {
  final String title; final IconData icon; final Color color; final VoidCallback onTap;
  const SidebarItem({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => ListTile(leading: Icon(icon, color: color), title: Text(title, style: GoogleFonts.poppins(fontWeight: FontWeight.w500)), onTap: onTap);
}

class MenuCard extends StatelessWidget {
  final String title; final IconData icon; final Color color; final VoidCallback onTap;
  const MenuCard({super.key, required this.title, required this.icon, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, child: Container(width: 100, height: 100, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.grey.shade200)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 40, color: color), const SizedBox(height: 8), Text(title, style: GoogleFonts.poppins(color: color, fontSize: 12, fontWeight: FontWeight.bold))])));
}