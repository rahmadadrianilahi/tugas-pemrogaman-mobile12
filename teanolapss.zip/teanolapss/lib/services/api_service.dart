import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/tea_model.dart';

class ApiService {
  final String baseUrl = "https://api-kamu.com/teas"; // Ganti dengan URL API Anda

  // --- FETCH TEAS (Ambil Semua Data Tea) ---
  Future<List<TeaModel>> fetchTeas() async {
    try {
      final response = await http.get(Uri.parse(baseUrl));

      if (response.statusCode == 200) {
        List jsonResponse = json.decode(response.body);
        return jsonResponse.map((data) => TeaModel.fromJson(data)).toList();
      } else {
        throw Exception('Gagal memuat data tea. Status: ${response.statusCode}');
      }
    } catch (e) {
      print("API Service Error: $e");
      // Return data dummy jika API error
      return _getDummyTeas();
    }
  }

  // --- GET TEA BY ID ---
  Future<TeaModel?> getTeaById(int id) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/$id'));

      if (response.statusCode == 200) {
        return TeaModel.fromJson(json.decode(response.body));
      } else {
        throw Exception('Tea tidak ditemukan');
      }
    } catch (e) {
      print("API Service Error: $e");
      return null;
    }
  }

  // --- CREATE TEA (Tambah Data) ---
  Future<bool> createTea(String nama, int harga, String deskripsi, String gambarUrl) async {
    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "nama": nama,
          "harga": harga,
          "deskripsi": deskripsi,
          "gambar": gambarUrl,
        }),
      );
      return response.statusCode == 201 || response.statusCode == 200;
    } catch (e) {
      print("Create Tea Error: $e");
      return false;
    }
  }

  // --- UPDATE TEA (Edit Data) ---
  Future<bool> updateTea(int id, String nama, int harga, String deskripsi, String gambarUrl) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/$id'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "nama": nama,
          "harga": harga,
          "deskripsi": deskripsi,
          "gambar": gambarUrl,
        }),
      );
      return response.statusCode == 200;
    } catch (e) {
      print("Update Tea Error: $e");
      return false;
    }
  }

  // --- DELETE TEA (Hapus Data) ---
  Future<bool> deleteTea(int id) async {
    try {
      final response = await http.delete(Uri.parse('$baseUrl/$id'));
      return response.statusCode == 200 || response.statusCode == 204;
    } catch (e) {
      print("Delete Tea Error: $e");
      return false;
    }
  }

  // --- DATA DUMMY (Fallback jika API error) ---
  List<TeaModel> _getDummyTeas() {
    return [
      TeaModel(
        id: 1,
        nama: "Teh Tarik Original",
        harga: 15000,
        deskripsi: "Teh tarik klasik dengan rasa manis gurih yang khas",
        gambarUrl: "https://placehold.co/600x400/FF6B6B/FFFFFF?text=Teh+Tarik",
      ),
      TeaModel(
        id: 2,
        nama: "Thai Tea",
        harga: 18000,
        deskripsi: "Teh Thailand dengan susu yang creamy dan manis",
        gambarUrl: "https://placehold.co/600x400/4ECDC4/FFFFFF?text=Thai+Tea",
      ),
      TeaModel(
        id: 3,
        nama: "Lemon Tea",
        harga: 12000,
        deskripsi: "Teh segar dengan perasan lemon asli",
        gambarUrl: "https://placehold.co/600x400/FFE66D/FFFFFF?text=Lemon+Tea",
      ),
      TeaModel(
        id: 4,
        nama: "Matcha Latte",
        harga: 22000,
        deskripsi: "Teh hijau Jepang premium dengan susu",
        gambarUrl: "https://placehold.co/600x400/95E1D3/FFFFFF?text=Matcha+Latte",
      ),
      TeaModel(
        id: 5,
        nama: "Teh Poci",
        harga: 10000,
        deskripsi: "Teh tradisional Indonesia dengan gula batu",
        gambarUrl: "https://placehold.co/600x400/F38181/FFFFFF?text=Teh+Poci",
      ),
      TeaModel(
        id: 6,
        nama: "Brown Sugar Milk Tea",
        harga: 20000,
        deskripsi: "Bubble tea dengan brown sugar dan pearl",
        gambarUrl: "https://placehold.co/600x400/AA96DA/FFFFFF?text=Brown+Sugar",
      ),
    ];
  }
}
