import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'; // Wajib untuk kIsWeb
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/order_model.dart';

class OrderProvider with ChangeNotifier {
  List<OrderModel> _orders = [];

  List<OrderModel> get orders => _orders;

  // 1. INISIALISASI DATABASE
  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'teanol_final.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE orders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, 
            namaPemesan TEXT, 
            namaTeh TEXT, 
            jumlah INTEGER, 
            totalHarga INTEGER, 
            tanggal TEXT
          )
        ''');
      },
    );
  }

  // 2. READ (AMBIL DATA)
  Future<void> fetchOrders() async {
    if (kIsWeb) return; // Web pakai RAM saja

    try {
      final db = await _initDB();
      final data = await db.query('orders', orderBy: 'id DESC');

      _orders = data.map((item) {
        return OrderModel(
          id: item['id'] as int,
          namaPemesan: item['namaPemesan'] as String,
          namaTeh: item['namaTeh'] as String,
          jumlah: item['jumlah'] as int,
          totalHarga: item['totalHarga'] as int,
          tanggal: item['tanggal'] as String,
        );
      }).toList();

      notifyListeners();
    } catch (e) {
      print("Error Load Database: $e");
    }
  }

  // 3. CREATE (TAMBAH DATA)
  Future<void> addOrder(OrderModel order) async {
    _orders.insert(0, order); // Masukkan ke paling atas list
    notifyListeners();

    if (kIsWeb) return;

    try {
      final db = await _initDB();
      await db.insert(
        'orders',
        {
          'namaPemesan': order.namaPemesan,
          'namaTeh': order.namaTeh,
          'jumlah': order.jumlah,
          'totalHarga': order.totalHarga,
          'tanggal': order.tanggal,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      // Fetch ulang biar dapat ID yang benar dari database
      await fetchOrders();
    } catch (e) {
      print("Error Simpan Database: $e");
    }
  }

  // 4. UPDATE (EDIT DATA) - FITUR BARU!
  Future<void> updateOrder(int id, int jumlahBaru, int totalHargaBaru) async {
    // Cari index di list lokal dan update
    final index = _orders.indexWhere((ord) => ord.id == id);
    if (index != -1) {
      // Kita buat object baru dengan data yang diupdate
      final oldData = _orders[index];
      _orders[index] = OrderModel(
        id: oldData.id,
        namaPemesan: oldData.namaPemesan,
        namaTeh: oldData.namaTeh,
        tanggal: oldData.tanggal,
        jumlah: jumlahBaru,      // Data Baru
        totalHarga: totalHargaBaru, // Data Baru
      );
      notifyListeners();
    }

    if (kIsWeb) return;

    try {
      final db = await _initDB();
      await db.update(
        'orders',
        {
          'jumlah': jumlahBaru,
          'totalHarga': totalHargaBaru,
        },
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      print("Error Update Database: $e");
    }
  }

  // 5. DELETE (HAPUS DATA)
  Future<void> deleteOrder(int id) async {
    _orders.removeWhere((item) => item.id == id);
    notifyListeners();

    if (kIsWeb) return;

    try {
      final db = await _initDB();
      await db.delete('orders', where: 'id = ?', whereArgs: [id]);
    } catch (e) {
      print("Error Hapus Database: $e");
    }
  }
}