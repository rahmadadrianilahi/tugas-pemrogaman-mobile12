import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthProvider with ChangeNotifier {
  bool _isLoggedIn = false;
  String _username = "Mahasiswa"; // Default nama

  bool get isLoggedIn => _isLoggedIn;
  String get username => _username;

  // Cek Status Login saat aplikasi dibuka
  Future<void> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey('isLogin')) return;

    _isLoggedIn = prefs.getBool('isLogin') ?? false;
    _username = prefs.getString('username') ?? "Mahasiswa";
    notifyListeners();
  }

  // Fungsi Login
  Future<void> login(String name, String password) async {
    // Simulasi: Password bebas, asal nama diisi
    _isLoggedIn = true;
    _username = name;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLogin', true);
    await prefs.setString('username', name);

    notifyListeners();
  }

  // Fungsi Logout
  Future<void> logout() async {
    _isLoggedIn = false;
    _username = "Mahasiswa";

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); // Hapus semua data login

    notifyListeners();
  }
}