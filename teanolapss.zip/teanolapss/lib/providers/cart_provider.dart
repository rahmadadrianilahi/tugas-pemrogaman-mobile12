import 'package:flutter/material.dart';
import '../models/tea_model.dart';
import '../models/cart_item_model.dart';

class CartProvider with ChangeNotifier {
  // Key menggunakan int karena TeaModel.id kamu bertipe int
  Map<int, CartItem> _items = {};

  Map<int, CartItem> get items {
    return {..._items};
  }

  int get itemCount {
    return _items.length;
  }

  double get totalAmount {
    var total = 0.0;
    _items.forEach((key, cartItem) {
      total += cartItem.tea.harga * cartItem.quantity;
    });
    return total;
  }

  // Fungsi Tambah Barang
  void addItem(TeaModel tea) {
    if (_items.containsKey(tea.id)) {
      // Update jumlah jika barang sudah ada
      _items.update(
        tea.id,
            (existing) => CartItem(
          id: existing.id,
          tea: existing.tea,
          quantity: existing.quantity + 1,
        ),
      );
    } else {
      // Tambah baru jika belum ada
      _items.putIfAbsent(
        tea.id,
            () => CartItem(
          id: DateTime.now().toString(),
          tea: tea,
          quantity: 1,
        ),
      );
    }
    notifyListeners();
  }

  // Fungsi Kurangi Barang
  void removeSingleItem(int teaId) {
    if (!_items.containsKey(teaId)) return;

    if (_items[teaId]!.quantity > 1) {
      _items.update(
        teaId,
            (existing) => CartItem(
          id: existing.id,
          tea: existing.tea,
          quantity: existing.quantity - 1,
        ),
      );
    } else {
      _items.remove(teaId);
    }
    notifyListeners();
  }

  // Bersihkan Keranjang
  void clearCart() {
    _items = {};
    notifyListeners();
  }
}