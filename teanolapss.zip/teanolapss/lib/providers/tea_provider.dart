import 'package:flutter/material.dart';
import '../models/tea_model.dart';

class TeaProvider with ChangeNotifier {
  List<TeaModel> _teas = [];
  bool _isLoading = false;

  List<TeaModel> get teas => _teas;
  bool get isLoading => _isLoading;

  // ================= FETCH TEAS (dipanggil dari dashboard) =================
  Future<void> fetchTeas() async {
    _isLoading = true;
    notifyListeners();

    // Simulasi delay loading (seperti fetch dari API)
    await Future.delayed(Duration(milliseconds: 500));

    // Load data dengan PATH GAMBAR YANG BENAR ✅
    _teas = [
      TeaModel(
          id: 1,
          nama: 'Nasi Goreng Spesial',
          harga: 25000,
          deskripsi: 'Nasi goreng dengan telur, ayam, dan sayuran segar',
          gambarUrl: 'assets/images/menu_screen/menu1.jpg', // ✅ PATH FIXED
      ),
      TeaModel(
        id: 2,
        nama: 'Pizza',
        harga: 50000,
        deskripsi: 'pizza dengan keju lumer',
        gambarUrl: 'assets/images/menu_screen/menu2.jpg', // ✅ PATH FIXED
      ),
      TeaModel(
        id: 3,
        nama: 'salad',
        harga: 40000,
        deskripsi: 'salad dengan menggunakan saos mayones',
        gambarUrl: 'assets/images/menu_screen/menu3.jpg', // ✅ PATH FIXED
      ),
      TeaModel(
        id: 4,
        nama: 'Pancake',
        harga: 22000,
        deskripsi: 'Kue pancake dengan madu',
        gambarUrl: 'assets/images/menu_screen/menu4.jpg', // ✅ PATH FIXED
      ),
      TeaModel(
        id: 5,
        nama: 'kue red velvet',
        harga: 18000,
        deskripsi: 'dengan cake yang lembut',
        gambarUrl: 'assets/images/menu_screen/menu5.jpg', // ✅ PATH FIXED
      ),
      TeaModel(
        id: 6,
        nama: 'sate kambing',
        harga: 12000,
        deskripsi: 'dengan daging yang lembut',
        gambarUrl: 'assets/images/menu_screen/menu6.jpg', // ✅ PATH FIXED
      ),
    ];

    _isLoading = false;
    print('✅ TeaProvider loaded: ${_teas.length} items with real images');
    notifyListeners();
  }

  // ================= LOAD DATA AWAL (DENGAN GAMBAR REAL) =================
  void loadInitialData() {
    _teas = [
      TeaModel(
        id: 1,
        nama: 'Nasi Goreng Spesial',
        harga: 25000,
        deskripsi: 'Nasi goreng dengan telur, ayam, dan sayuran segar',
        gambarUrl: 'assets/images/menu_screen/menu1.jpg',
      ),
      TeaModel(
        id: 2,
        nama: 'Pizza',
        harga: 50000,
        deskripsi: 'pizza dengan keju lumer',
        gambarUrl: 'assets/images/menu_screen/menu2.jpg',
      ),
      TeaModel(
        id: 3,
        nama: 'salad',
        harga: 40000,
        deskripsi: 'salad dengan menggunakan saos mayones',
        gambarUrl: 'assets/images/menu_screen/menu3.jpg',
      ),
      TeaModel(
        id: 4,
        nama: 'Pancake',
        harga: 22000,
        deskripsi: 'Kue pancake dengan madu',
        gambarUrl: 'assets/images/menu_screen/menu4.jpg',
      ),
      TeaModel(
        id: 5,
        nama: 'kue red velvet',
        harga: 18000,
        deskripsi: 'dengan cake yang lembut',
        gambarUrl: 'assets/images/menu_screen/menu5.jpg',
      ),
      TeaModel(
        id: 6,
        nama: 'sate kambing',
        harga: 12000,
        deskripsi: 'dengan daging yang lembut',
        gambarUrl: 'assets/images/menu_screen/menu6.jpg',
      ),
    ];

    print('✅ TeaProvider loaded: ${_teas.length} items with real images');
    notifyListeners();
  }

  // ================= CREATE (Tambah Menu) =================
  void addTea(TeaModel tea) {
    _teas.add(tea);
    print('➕ Added: ${tea.nama}');
    notifyListeners();
  }

  // ================= READ (Cari Menu by ID) =================
  TeaModel? getTeaById(int id) {
    try {
      return _teas.firstWhere((tea) => tea.id == id);
    } catch (e) {
      return null;
    }
  }

  // ================= UPDATE (Edit Menu) =================
  void updateTea(int id, TeaModel updatedTea) {
    final index = _teas.indexWhere((tea) => tea.id == id);
    if (index != -1) {
      _teas[index] = updatedTea;
      print('✏️ Updated: ${updatedTea.nama}');
      notifyListeners();
    }
  }

  // ================= DELETE (Hapus Menu) =================
  void deleteTea(int id) {
    final tea = _teas.firstWhere((t) => t.id == id);
    _teas.removeWhere((tea) => tea.id == id);
    print('🗑️ Deleted: ${tea.nama}');
    notifyListeners();
  }

  // ================= SEARCH (Cari Menu) =================
  List<TeaModel> searchTeas(String query) {
    if (query.isEmpty) return _teas;

    return _teas.where((tea) {
      return tea.nama.toLowerCase().contains(query.toLowerCase()) ||
          tea.deskripsi.toLowerCase().contains(query.toLowerCase());
    }).toList();
  }

  // ================= FILTER BY PRICE (Filter Harga) =================
  List<TeaModel> getTeasByPriceRange(int minPrice, int maxPrice) {
    return _teas.where((tea) {
      return tea.harga >= minPrice && tea.harga <= maxPrice;
    }).toList();
  }

  // ================= CLEAR ALL (Hapus Semua) =================
  void clearAll() {
    _teas.clear();
    print('🗑️ All menus cleared');
    notifyListeners();
  }
}