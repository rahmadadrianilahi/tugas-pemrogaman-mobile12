package com.example.teanolapss

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
