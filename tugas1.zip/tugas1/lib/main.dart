import 'package:flutter/material.dart';
import 'screens/profile_screen.dart'; // Import halaman profil

void main() {
  runApp(const ProfilPribadiApp());
}

class ProfilPribadiApp extends StatelessWidget {
  const ProfilPribadiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profil Pribadi Ahmad',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      // Langsung panggil Screen yang ada di folder screens
      home: const ProfileScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}