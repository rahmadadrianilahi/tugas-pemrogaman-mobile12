import 'package:flutter/material.dart';

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap; // Tambahan: Menerima fungsi ketika diklik

  const InfoCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap, // Tambahan
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      clipBehavior: Clip.hardEdge, // Tambahan: Agar efek klik tidak keluar border
      child: InkWell( // Tambahan: InkWell memberikan efek animasi "cipratan air" saat diklik
        onTap: onTap,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.blue[50],
            child: Icon(icon, color: Colors.blueAccent),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey), // Tambahan: Panah kecil
        ),
      ),
    );
  }
}