import 'package:flutter/material.dart';
import '../widgets/profile_header.dart';
import '../widgets/info_card.dart';
import '../widgets/skill_chip.dart';
import '../widgets/project_card.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _handleAction(BuildContext context, String actionName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Membuka $actionName... (Fitur akan segera hadir)'),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.blueAccent,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text('Profil Saya', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const ProfileHeader(),
            const SizedBox(height: 20),
            
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Tentang Saya",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Saya mahasiswa IT angkatan 2023. Saya suka membangun aplikasi yang bermanfaat dan memiliki tampilan yang menarik.',
                    style: TextStyle(fontSize: 15, color: Colors.black54, height: 1.5),
                    textAlign: TextAlign.justify,
                  ),

                  const SizedBox(height: 25),

                  const Text(
                    "Projek Unggulan",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 15),
                  
                  SizedBox(
                    height: 180, 
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: const [
                        ProjectCard(
                          projectName: "Aplikasi Kasir",
                          description: "Aplikasi POS sederhana untuk UMKM menggunakan Flutter.",
                          icon: Icons.store, // PERBAIKAN: Menggunakan Icons.store
                          color: Colors.orange,
                        ),
                        ProjectCard(
                          projectName: "Website Sekolah",
                          description: "Profil sekolah dengan HTML, CSS, dan JS.",
                          icon: Icons.language, // PERBAIKAN: Menggunakan Icons.language
                          color: Colors.blue,
                        ),
                        ProjectCard(
                          projectName: "Game Kuis",
                          description: "Game edukasi tebak gambar hewan.",
                          icon: Icons.games, // PERBAIKAN: Menggunakan Icons.games
                          color: Colors.purple,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 25),
                  
                  const Text(
                    "Hubungi Saya",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  
                  InfoCard(
                    icon: Icons.email,
                    title: "Email",
                    subtitle: "ahmad@email.com",
                    onTap: () => _handleAction(context, "Email"),
                  ),
                  InfoCard(
                    icon: Icons.chat,
                    title: "WhatsApp",
                    subtitle: "+62 812 3456 7890",
                    onTap: () => _handleAction(context, "WhatsApp"),
                  ),
                  InfoCard(
                    icon: Icons.map,
                    title: "Lokasi",
                    subtitle: "Jambi, Indonesia",
                    onTap: () => _handleAction(context, "Google Maps"),
                  ),

                  const SizedBox(height: 25),

                  const Text(
                    "Tech Stack",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  
                  const Wrap(
                    spacing: 8.0,
                    runSpacing: 8.0,
                    children: [
                      SkillChip(label: "Flutter"),
                      SkillChip(label: "Dart"),
                      SkillChip(label: "Laravel"),
                      SkillChip(label: "MySQL"),
                      SkillChip(label: "Git"),
                    ],
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}